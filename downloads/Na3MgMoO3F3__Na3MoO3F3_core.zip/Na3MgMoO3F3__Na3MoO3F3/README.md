# Na3MgMoO3F3__Na3MoO3F3

Na3MgMoO3F3 / mp-2240200;mp-2240370；Na3MoO3F3 / mp-18753

首批附件 38 份，补充明细 10 份。先下载 [core ZIP](../../downloads/Na3MgMoO3F3__Na3MoO3F3_core.zip)，解压后按 [ATTACHMENTS.csv](ATTACHMENTS.csv) 上传；文件较多时在同一对话分批，全部上传后再开始分析。

- [最终报告](core/REPORT.md)
- [可复制提示词](UPLOAD_PROMPT.md)
- [全部首批文件](core/)
- [按需补充文件](details/)

## 使用边界

Na3MgMoO3F3包含mp-2240200（源32）、mp-2240370（源33/用户34）；mp-18753是另一组成Na3MoO3F3的参照。三者分别保留，不能归为三个同组成重复。

1200 K单温短轨迹提供运动和环境对应证据。规则候选、参考球返回、几何连接和诊断斜率各有不同定义；科学独立接受状态为 `UNVERIFIED`。报告中的旧执行许可不适用于本公开包。原始轨迹、NPZ/NPY、生产源码及私人执行历史不包含在内。

## 上传顺序

先 REPORT 和方法，再摘要/逐Na/MSD/事件对照表，最后PNG。补充details只在具体问题需要时追加。CSV.gz先在本地解压；网页工具需实际读到文件和字段再分析，仓库链接本身不等于附件已读。
